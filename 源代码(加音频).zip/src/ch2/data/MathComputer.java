package ch2.data;
public interface MathComputer {
   public void handle(Computer data);
}