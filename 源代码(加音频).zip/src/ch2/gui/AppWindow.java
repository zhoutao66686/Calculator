package ch2.gui;
import ch2.view.CalculatorWindow;
public class AppWindow {
   public static void main(String [] args) {
      CalculatorWindow win = new CalculatorWindow(); 
   }
}